#ifndef LINEADETEXTO
#define LINEADETEXTO

#include <QLineEdit>
#include <QString>
#include <QTreeWidget>
#include <QTimer>
#include <QStringList>
#include <QHeaderView>
#include <QKeyEvent>
#include "cliente.h"

class LineaDeTexto : public QLineEdit
{
    Q_OBJECT

public:
    LineaDeTexto( QWidget * parent = nullptr );
    LineaDeTexto( const LineaDeTexto & linea );
    LineaDeTexto & operator=( const LineaDeTexto & linea );
    LineaDeTexto operator+( const LineaDeTexto & linea );

private:
    QTreeWidget * popup;
    QTimer * timer;

    QVector< Cliente > v;

    void crearPopup();
    bool eventFilter( QObject * obj, QEvent * ev );
    void completarPopup( QVector< QStringList > vector );

private slots:
    void slot_sugerencia();
    void slot_completarLineEdit();
};


#endif // LINEADETEXTO

