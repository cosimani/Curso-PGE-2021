#ifndef CLIENTE_H
#define CLIENTE_H

#include <QString>

class Cliente  {
public:
    Cliente( QString nombre = "Nombre",
             QString apellido = "Apellido",
             QString empresa = "Empresa" ) : nombre( nombre ),
                                             apellido( apellido ),
                                             empresa( empresa )  {
    }

    QString getNombre() const;
    void setNombre( const QString & value );

    QString getApellido() const;
    void setApellido( const QString & value );

    QString getEmpresa() const;
    void setEmpresa( const QString & value );

private:
    QString nombre;
    QString apellido;
    QString empresa;
};


#endif // CLIENTE_H
