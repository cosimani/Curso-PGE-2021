#include "cliente.h"

QString Cliente::getNombre() const  {
    return nombre;
}

void Cliente::setNombre( const QString & value )  {
    nombre = value;
}

QString Cliente::getApellido() const  {
    return apellido;
}

void Cliente::setApellido( const QString & value )  {
    apellido = value;
}

QString Cliente::getEmpresa() const  {
    return empresa;
}

void Cliente::setEmpresa( const QString & value )  {
    empresa = value;
}
