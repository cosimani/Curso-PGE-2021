#include "lineadetexto.h"

LineaDeTexto::LineaDeTexto( QWidget * parent) : QLineEdit( parent )  {
    this->crearPopup();

    v.push_back( Cliente( "Carlos", "Ponce", "Santander" ) );
    v.push_back( Cliente( "Miguel", "Abuelo", "Santander" ) );
    v.push_back( Cliente( "Jose", "Feliciano", "SmartCampus" ) );
    v.push_back( Cliente( "Raul", "Carnota", "SmartCampus" ) );
    v.push_back( Cliente( "Jorge", "Fandermole", "SmartCampus" ) );
    v.push_back( Cliente( "Carlos", "Guastavino", "Despegar" ) );
    v.push_back( Cliente( "Franco", "Barrionuevo", "Despegar" ) );
    v.push_back( Cliente( "Juan", "Gabriel", "Changos" ) );
}

LineaDeTexto::LineaDeTexto( const LineaDeTexto & linea ) : QLineEdit()  {
    this->setText( linea.text() );
}

LineaDeTexto & LineaDeTexto::operator=( const LineaDeTexto & linea )  {
    this->setText( linea.text() );
    return *this;
}

LineaDeTexto LineaDeTexto::operator+( const LineaDeTexto & linea )  {
    LineaDeTexto lineaDeTexto;
    lineaDeTexto.setText( this->text() + linea.text() );
    return lineaDeTexto;
}

void LineaDeTexto::crearPopup()  {
    popup = new QTreeWidget;
    popup->setColumnCount( 3 );
    popup->setRootIsDecorated( false );  // Elimina el lugar del icono de la izquierda.
    popup->header()->hide();  // Oculta la cabecera
    popup->installEventFilter( this );

    connect( popup, SIGNAL( itemClicked( QTreeWidgetItem *, int ) ), SLOT( slot_completarLineEdit() ) );

    popup->setWindowFlags( Qt::Popup );  // Para que la ventana sea estilo popup
    timer = new QTimer( this );
    timer->setSingleShot( true );
    timer->setInterval( 200 );

    // Cada 200 mseg busca coincidencias
    connect( timer, SIGNAL( timeout() ), SLOT( slot_sugerencia() ) );
    connect( this, SIGNAL( textEdited( QString ) ), timer, SLOT( start() ) );

}

bool LineaDeTexto::eventFilter( QObject * obj, QEvent * ev )  {
    if ( obj == popup )  {
        if ( ev->type() == QEvent::MouseButtonPress )  {
            popup->hide();
            this->setFocus();
            return true;
        }

        if ( ev->type() == QEvent::KeyPress )  {
            bool reconocido = false;
            int key = static_cast< QKeyEvent * >( ev )->key();
            switch ( key )  {
            case Qt::Key_Enter:
            case Qt::Key_Tab:
            case Qt::Key_Return:
                this->slot_completarLineEdit();
                reconocido = true;
                break;
            case Qt::Key_Escape:
                this->setFocus();
                // Si se presiona escape entonces limpiamos.
                this->clear();
                popup->hide();
                reconocido = true;

            case Qt::Key_Up:
            case Qt::Key_Down:
            case Qt::Key_Home:
            case Qt::Key_End:
            case Qt::Key_PageUp:
            case Qt::Key_PageDown:
                break;

            default:
                // Hace que permanezca el cursor en el QLineEdit y poder seguir escribiendo
                this->event( ev );
                popup->hide();
                break;
            }
            return reconocido;
        }
    }
    return false;
}

void LineaDeTexto::slot_completarLineEdit()  {
    timer->stop();
    popup->hide();
    this->setFocus();

    QTreeWidgetItem * item = popup->currentItem();

    if ( item )  {
        // Seteamos el QLineEdit con el texto del nombre del producto elegido.
        this->setText( item->text( 0 ) + " " + item->text( 1 ) + " (" + item->text( 2 ) + ")" );
    }
}

void LineaDeTexto::slot_sugerencia()   {
    QVector< QStringList > vectorCoincidencias;  // Almacenará las sugerencias
    QString cadena = this->text();

    for (int i = 0, contador = 0 ; i < v.size() && contador < 6 ; i++)  {

        Cliente cliente = v.at( i );
        QString empresa = cliente.getEmpresa();

        if ( empresa.contains( cadena, Qt::CaseInsensitive ) )  {
            QStringList sugerencia;
            sugerencia << cliente.getNombre() << cliente.getApellido() << cliente.getEmpresa();
            vectorCoincidencias.push_back( sugerencia );
            contador++;
        }
    }

    // Si no existe lo que se busca se limpia el QLineEdit.
    if ( vectorCoincidencias.size() == 0 )  {

        // Aqui colocamos todos los datos de la siguiente forma:
        // Santander-Ponce-Carlos
        // Santander-Abuelo-Miguel
        // etc. De esta manera podemos usar el sort de QStringList para ordenar y luego usamos el split
        QStringList datosAlRevesOrdenados;

        for ( int i = 0 ; i < v.size() ; i++ )  {
            QString linea = v.at( i ).getEmpresa() + "-" + v.at( i ).getApellido() + "-" + v.at( i ).getNombre();
            datosAlRevesOrdenados.append( linea );
        }

        datosAlRevesOrdenados.sort( Qt::CaseInsensitive );

        QVector< Cliente > vOrdenados;

        for ( int i = 0 ; i < datosAlRevesOrdenados.size() ; i++ )  {
            QString linea = datosAlRevesOrdenados.at( i );
            QStringList empresa_apelldio_nombre = linea.split( "-" );
            vOrdenados.append( Cliente( empresa_apelldio_nombre.at( 2 ),
                                        empresa_apelldio_nombre.at( 1 ),
                                        empresa_apelldio_nombre.at( 0 ) ) );
        }



        for ( int i = 0 ; i < vOrdenados.size() && i < 5 ; i++)  {
            QStringList sugerencia;
            Cliente cliente = vOrdenados.at( i );
            sugerencia << cliente.getNombre() << cliente.getApellido() << cliente.getEmpresa();
            vectorCoincidencias.push_back( sugerencia );
        }
    }

    // Completa el popup con las sugerencias
    this->completarPopup( vectorCoincidencias );
}

/**
  * Completa el QTreeWidget con el resultado de la consulta a la base de datos y lo visualiza.
  */
void LineaDeTexto::completarPopup( QVector< QStringList > vector )  {
    popup->clear();

    for ( int i = 0; i < vector.size(); ++i )  {
        QTreeWidgetItem * item;
        item = new QTreeWidgetItem( popup );
        item->setText( 0, vector.at( i ).at( 0 ) );
        item->setText( 1, vector.at( i ).at( 1 ) );
        item->setText( 2, vector.at( i ).at( 2 ) );
        item->setTextAlignment( 2, Qt::AlignRight );  // Para alinear contra la derecha
    }

    popup->setCurrentItem ( popup->topLevelItem( 0 ) );  // Queda seleccionado el primer elemento

    // Este numero 20 es la cantidad de lineas que tiene la lista desplegable
    int h = popup->sizeHintForRow( 0 ) * qMin( 20, vector.size() ) + 3;

    // El ancho del popup es igual al ancho del QLineEdit
    popup->resize( this->width(), h );

    // Lo posiciona justo abajo del QLineEdit
    popup->move( this->mapToGlobal( QPoint( 0, this->height() ) ) );

    popup->setFocus();
    popup->show();
}


