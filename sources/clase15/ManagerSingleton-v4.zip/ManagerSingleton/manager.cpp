#include "manager.h"
#include "login.h"
#include "formulario.h"

Manager * Manager::that = nullptr;

Manager::Manager( QObject * parent ) : QObject( parent )
{
//    connect( login, SIGNAL( signal_usuarioValido() ),
//             formulario, SLOT( show() ) );

    connect( Login::get(), &Login::signal_usuarioValido, this, [ & ]()  {
        Login::get()->hide();
        Login::get()->vaciarCampos();
        Formulario::get()->show();
    }  );

    connect( Formulario::get(), &Formulario::signal_nuevoUsuario,
             Login::get(), &Login::slot_agregarUsuario );

    connect( Formulario::get(), &Formulario::signal_cerrado,
             Login::get(), &Login::show );

}

void Manager::iniciar()
{
    Login::get()->show();
}

Manager * Manager::get()  {
    if ( that == nullptr )
        that = new Manager;
    return that;
}
