#ifndef FORMULARIO_H
#define FORMULARIO_H

#include <QWidget>


class Login;

namespace Ui {
class Formulario;
}

class Formulario : public QWidget
{
    Q_OBJECT

public:
    explicit Formulario(QWidget *parent = 0);
    ~Formulario();

    void setLogin( Login * login );

private:
    Ui::Formulario *ui;

    Login * login;

private slots:
    void slot_volver();
};

#endif // FORMULARIO_H
