#include "login.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Login w;
    w.show();

    // w.validarCon( "../base.sqlite", "usuarios", "usuario", "clave" );

    return a.exec();
}
