#include "formulario.h"
#include "ui_formulario.h"

#include "login.h"

Formulario::Formulario(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Formulario)
{
    ui->setupUi(this);

    connect(ui->pbVolver, SIGNAL(pressed()),this, SLOT(slot_volver()));
}

Formulario::~Formulario()
{
    delete ui;
}

void Formulario::setLogin(Login *login)
{
    this->login = login;
}

void Formulario::slot_volver()
{
    login->show();
    this->hide();
}
