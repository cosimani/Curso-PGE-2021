#ifndef FORMULARIO_H
#define FORMULARIO_H

#include <QWidget>

namespace Ui {
class Formulario;
}

class Formulario : public QWidget
{
    Q_OBJECT

public:
    explicit Formulario(QWidget *parent = 0);
    ~Formulario();

private:
    Ui::Formulario *ui;

signals:
    void signal_listo();

};

#endif // FORMULARIO_H
