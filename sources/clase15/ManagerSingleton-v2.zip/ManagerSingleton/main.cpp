#include <QApplication>
#include "manager.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    Manager manager;
    manager.iniciar();

    // w.validarCon( "../base.sqlite", "usuarios", "usuario", "clave" );

    return a.exec();
}
