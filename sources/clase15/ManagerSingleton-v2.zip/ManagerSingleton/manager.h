#ifndef MANAGER_H
#define MANAGER_H

#include <QObject>

class Login;
class Formulario;

class Manager : public QObject
{
    Q_OBJECT
public:
    explicit Manager(QObject *parent = nullptr);

    void iniciar();

private:
    Login * login;
    Formulario * formulario;

signals:

public slots:
};

#endif // MANAGER_H
