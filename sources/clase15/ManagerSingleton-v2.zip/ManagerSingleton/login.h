#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>

namespace Ui {
class Login;
}

class Login : public QWidget
{
    Q_OBJECT

public:
    explicit Login(QWidget *parent = 0);
    ~Login();

    bool validarCon( QString archvioSqlite,
                     QString tabla,
                     QString campoUsuario,
                     QString campoClave );

    void vaciarCampos();

private:
    Ui::Login *ui;

    QVector< QStringList > baseUsuarios;



signals:
    void signal_usuarioValido();

private slots:
    void slot_validarUsuario();

};

#endif // LOGIN_H
