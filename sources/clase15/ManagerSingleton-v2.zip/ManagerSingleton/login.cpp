#include "login.h"
#include "ui_login.h"

#include "formulario.h"

Login::Login(QWidget *parent) : QWidget(parent),
    ui(new Ui::Login)
{
    ui->setupUi(this);

    baseUsuarios.append( QStringList() << "admin" << "1234" );
    baseUsuarios.append( QStringList() << "cponce" << "1234" );

    connect( ui->pb, SIGNAL( pressed() ), this, SLOT( slot_validarUsuario() ) );
    connect( ui->leUsuario, SIGNAL( returnPressed() ), this, SLOT( slot_validarUsuario() ) );
    connect( ui->leClave, SIGNAL( returnPressed() ), this, SLOT( slot_validarUsuario() ) );
}

Login::~Login()  {
    delete ui;
}

bool Login::validarCon( QString archvioSqlite, QString tabla,
                        QString campoUsuario, QString campoClave )
{
    Q_UNUSED( archvioSqlite );
    Q_UNUSED( tabla );
    Q_UNUSED( campoUsuario );
    Q_UNUSED( campoClave );

    return false;
}

void Login::vaciarCampos()  {
    ui->leUsuario->clear();
    ui->leClave->clear();
    ui->leUsuario->setFocus();
}

void Login::slot_validarUsuario()  {
    QStringList usuarioEscrito;
    usuarioEscrito << ui->leUsuario->text() << ui->leClave->text();

    if ( baseUsuarios.contains( usuarioEscrito ) )  {
        emit signal_usuarioValido();
    }
}




