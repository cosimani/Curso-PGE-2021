#include "manager.h"
#include "login.h"
#include "formulario.h"

Manager::Manager( QObject * parent ) : QObject( parent ),
                                       login( new Login ) ,
                                       formulario( new Formulario )
{
//    connect( login, SIGNAL( signal_usuarioValido() ),
//             formulario, SLOT( show() ) );

    connect( login, &Login::signal_usuarioValido, this, [ & ]()  {
        login->hide();
        login->vaciarCampos();
        formulario->show();
    }  );

    connect( formulario, &Formulario::signal_listo, this, [ & ]()  {
        login->show();
        formulario->hide();
    }  );
}

void Manager::iniciar()
{
    login->show();
}
