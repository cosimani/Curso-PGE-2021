#include "formulario.h"
#include "ui_formulario.h"

Formulario::Formulario(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Formulario)
{
    ui->setupUi(this);

//    connect( ui->pbAlta, SIGNAL( pressed() ), this, SIGNAL( signal_listo() ) );
//    connect( ui->pbAlta, SIGNAL( pressed() ), SIGNAL( signal_listo() ) );
//    connect( ui->pbAlta, &QPushButton::pressed, &Formulario::signal_listo );
//    connect( ui->pbAlta, &QPushButton::pressed, this, &Formulario::signal_listo );

//    connect( ui->pbAlta, &QPushButton::pressed, [ & ]()  {
//        emit signal_listo();
//    }  );

    connect( ui->pbAlta, &QPushButton::pressed, this, [ & ]()  {
        emit signal_listo();
    }  );

}

Formulario::~Formulario()
{
    delete ui;
}
