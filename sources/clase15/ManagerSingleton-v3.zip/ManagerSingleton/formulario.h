#ifndef FORMULARIO_H
#define FORMULARIO_H

#include <QWidget>

namespace Ui {
class Formulario;
}

class Formulario : public QWidget
{
    Q_OBJECT

    explicit Formulario(QWidget *parent = 0);
    static Formulario * that;

public:    
    ~Formulario();    
    static Formulario * get();

private:
    Ui::Formulario *ui;

signals:
    void signal_listo();

};

#endif // FORMULARIO_H
