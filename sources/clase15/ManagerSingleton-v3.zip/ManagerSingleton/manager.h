#ifndef MANAGER_H
#define MANAGER_H

#include <QObject>

class Login;
class Formulario;

class Manager : public QObject
{
    Q_OBJECT

public:
    static Manager * get();
    static Manager * that;

    void iniciar();

private:
    explicit Manager( QObject * parent = nullptr );

signals:

public slots:
};


#endif // MANAGER_H
