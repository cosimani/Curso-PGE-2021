#ifndef ESCENA_H
#define ESCENA_H

#include "ogl.h"

class Escena : public Ogl  {
    Q_OBJECT

public:
    Escena( QWidget * parent = 0 );

protected:
    void initializeGL();
    void resizeGL( int ancho, int alto );
    void paintGL();

private:
    void cargarTexturas();
    unsigned char *textura;
    GLuint idTextura;
};



#endif // ESCENA_H
