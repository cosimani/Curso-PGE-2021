#include <QApplication>
#include "escena.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    Escena w;
    w.show();

    return a.exec();
}
