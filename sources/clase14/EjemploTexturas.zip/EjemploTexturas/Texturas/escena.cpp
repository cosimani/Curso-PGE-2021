#include "escena.h"
#include <QMessageBox>
#include <GL/glu.h>

Escena::Escena( QWidget *parent ) : Ogl( parent )  {

}

void Escena::initializeGL()  {

    this->cargarTexturas();

    glEnable( GL_TEXTURE_2D );
    glClearColor( 0, 0, 0, 0 );
    glEnable( GL_DEPTH_TEST );
}

void Escena::resizeGL(int ancho, int alto)  {
    glViewport( 0, 0, ancho, alto );
    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();
    gluPerspective( 45, ancho/alto, 1, 100 );
    glMatrixMode( GL_MODELVIEW );
}

void Escena::paintGL()  {
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    glLoadIdentity();

    glEnable( GL_TEXTURE_2D );	// Activamos la texturizacion
    glBindTexture( GL_TEXTURE_2D, idTextura );	// Activamos la textura con idTextura

    glBegin(GL_QUADS);
        glTexCoord2f(0, 0);  glVertex3f(-2, -2,  -8);
        glTexCoord2f(1, 0);  glVertex3f( 2, -2,  -8);
        glTexCoord2f(1, 1);  glVertex3f( 2,  2,  -8);
        glTexCoord2f(0, 1);  glVertex3f(-2,  2,  -8);
    glEnd();

    glDisable(GL_TEXTURE_2D);  // La deshabilitamos solo para recordar que estamos usando texturas

    glFlush();
}

void Escena::cargarTexturas()   {
    QImage im;

    if ( ! im.load( "../recursos/tierra.jpg" ) )
        QMessageBox::critical( this, "Recurso no disponible", "La imagen no pudo ser cargada." );

    im = QGLWidget::convertToGLFormat( im );
    textura = im.bits();

    glGenTextures( 1, &idTextura );  // Generamos 1 textura. Guardamos su id en idTextura.
    glBindTexture( GL_TEXTURE_2D, idTextura );  // Activamos idTextura.

    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR ); // GL_LINEAR - Interpolaci�n
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR ); // GL_NEAREST - Sin

    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );  // GL_REPEAT - Permite repetir

    glTexImage2D( GL_TEXTURE_2D, 0, 3, im.width(), im.height(), 0, GL_RGBA, GL_UNSIGNED_BYTE, textura );
}

